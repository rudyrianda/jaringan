public class A {
    String halo = "Hello, This is class A in belajar1";
    public static void main(String[] args) {
        System.out.println("This is class A in Belajar1");
    }
    public void info() {
        System.out.println(halo);
    }
}
