package Lingkaran2;

import java.awt.geom.Point2D;

public class Lingkaran {
    double radius;
    Point2D.Double center;
    public Lingkaran(){
        radius = 2;
        center = new Point2D.Double(0,0);
    }
    public Lingkaran(double radius, double x, double y){
        this.radius = radius;
        center = new Point2D.Double(x,y);
    }
    public double getRadius() {
        return radius;
    }
    public void setRadius(double radius) {
        this.radius = radius;
    }
    public double getX() {
        return center.x;
    }
    public void setX(double x) {
        center.x = x;
    }
    public double getY() {
        return center.y;
    }
    public void setY(double y) {
        center.y = y;
    }
    public double getArea(){
        return Math.PI * radius * radius;
    }
    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Lingkaran dengan radius " + radius + " dan center di (" + center.x + ", " + center.y + ")";
    }
}
