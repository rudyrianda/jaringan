package Lingkaran2;

import java.awt.geom.Point2D;


public class Lingkaran2D {
    double radius;
    Point2D.Double center;
    public Lingkaran2D(double radius, Point2D.Double center) {
        this.radius = radius;
        this.center = center;
    }
    public Lingkaran2D(Point2D.Double center, double radius){
        this.radius = radius;
        this.center = center;
    }
    public Lingkaran2D(double radius){
        this.radius = radius;
        this.center = new Point2D.Double(0,0);
    }
    public Lingkaran2D(double radius, double x, double y){
        this.radius = radius;
        this.center = new Point2D.Double(x,y);
    }
    public Lingkaran2D(){
        this.radius = 2;
        this.center = new Point2D.Double(0,0);
    }
    public Lingkaran2D(double x, double y){
        this.radius = 2;
        this.center = new Point2D.Double(x,y);
    }
    public Lingkaran2D(Point2D.Double center){
        this.radius = 2;
        this.center = center;
    }
    public double distance(Lingkaran2D other){
        //X = (x2 - x1)^2
        //Y = (y2 - y1)^2
        //sqrt(X+Y)
        double X = Math.pow(other.center.getX() - this.center.getX(),2);
        double Y = Math.pow(other.center.getY() - this.center.getY(),2);
        return Math.sqrt(X + Y);
    }
    public boolean isBeririsan(Lingkaran2D other){
        double dist = this.distance(other);
        return dist <= (this.radius + other.radius);
    }
    public double getRadius() {
        return radius;
    }
    public void setRadius(double radius) {
        this.radius = radius;
    }
    public Point2D.Double getCenter() {
        return center;
    }
    public void setCenter(Point2D.Double center) {
        this.center = center;
    }
    public double getArea(){
        return Math.PI * radius * radius;
    }
    public double getCircumference(){
        return 2 * Math.PI * radius;
    }
    @Override
    public String toString() {
        return "Lingkaran2D{" +
                "radius=" + radius +
                ", center=" + center +
                '}';
    }
}
