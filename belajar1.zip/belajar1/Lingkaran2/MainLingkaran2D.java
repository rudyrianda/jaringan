package Lingkaran2;
import java.awt.geom.Point2D;

public class MainLingkaran2D {
    public static void main(String[] args) {
        Lingkaran2D obj1 = new Lingkaran2D();// default radius 1, center (0,0)
        Lingkaran2D obj2 = new Lingkaran2D(5, new Point2D.Double(10,0));
        Lingkaran2D obj3 = new Lingkaran2D(5, 4, 0);

        System.out.println("Lingkaran 1: " + obj1);
        System.out.println("Lingkaran 2: " + obj2);
        System.out.println("Lingkaran 3: " + obj3);
        System.out.println("Objek 1 dengan Objek 2: " + obj1.isBeririsan(obj2));
        System.out.println("Objek 1 dengan Objek 3: " + obj1.isBeririsan(obj3));
    }
}
