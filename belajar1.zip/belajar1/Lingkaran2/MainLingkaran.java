package Lingkaran2;

public class MainLingkaran {
    public static void main(String[] args) {
        Lingkaran lingkaran1 = new Lingkaran();
        Lingkaran lingkaran2 = new Lingkaran(7, 0, 0);
        //System.out.println("Radius Lingkaran 1: " + lingkaran1.getRadius());
        System.out.println("Luas Lingkaran 1: " + lingkaran1.getArea());
        //System.out.println("Center Lingkaran 1: (" + lingkaran1.getX() + ", " + lingkaran1.getY() + ")");
        System.out.println(lingkaran1.toString());
        System.out.println("================================");
        //System.out.println("Radius Lingkaran 2: " + lingkaran2.getRadius());
        System.out.println("Luas Lingkaran 2: " + lingkaran2.getArea());
        //System.out.println("Center Lingkaran 2: (" + lingkaran2.getX() + ", " + lingkaran2.getY() + ")");
        System.out.println(lingkaran2.toString());
    }
}
