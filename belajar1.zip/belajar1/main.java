public class main {
    public static void main(String[] args) {
        A varRoot = new A();
        layer1.A varLayer1A = new layer1.A();
        layer1.B varLayer1B = new layer1.B();
        layer1.layer2.A varLayer2A = new layer1.layer2.A();
        System.out.println(varLayer1A.halo);
        System.out.println(varLayer1B.halo);
        System.out.println(varLayer2A.halo);
        System.out.println(varRoot.halo);
        varRoot.info();
    }
}
