package encapsulation;

public class Vehicle {
    public double load;
    public double maxload;

    public Vehicle(double maxload){
        this.maxload = maxload;
    }
    
    public double getLoad(){
        return load;
    }

    public double getMaxload(){
        return maxload;
    }
}