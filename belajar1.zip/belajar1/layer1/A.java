package layer1;
public class A {
    public String halo = "This is class A in layer1";
    public static void main(String[] args) {
        System.out.println("This is class A in layer1");
    }
}
