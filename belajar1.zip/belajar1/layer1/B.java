package layer1;

public class B{
    public String halo = "This is class B in layer1";
    public static void main(String[] args) {
        System.out.println("This is class B in layer1");
    }
}
