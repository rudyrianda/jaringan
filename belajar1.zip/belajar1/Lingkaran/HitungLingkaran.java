package Lingkaran;

public class HitungLingkaran {

    static void hitungLuas (double radius){
        double luas = Math.PI * radius * radius;
        System.out.println("Luas Lingkaran dengan jari-jari " + radius + " adalah " + luas);
    }
    static void hitungKeliling (double radius){
        double keliling = 2 * Math.PI * radius;
        System.out.println("Keliling Lingkaran dengan jari-jari " + radius + " adalah " + keliling);
    }
}
