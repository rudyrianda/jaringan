package Lingkaran;

public class Lingkaran{
    double radius;
    double Luas;
    public Lingkaran(double Luas){
        this.Luas = Luas;
        this.radius = Math.sqrt(Luas/Math.PI);
    }
    public Lingkaran(double Luas, double radius){
        this.radius = radius;
        this.Luas = Luas;
    }

    public void printLingkaran(){
        System.out.println("Luas lingkaran : " + this.Luas + " dengan radius : " + this.radius);
    }

    public static void main(String[] args) {
        HitungLingkaran.hitungLuas(14);
        HitungLingkaran.hitungKeliling(7);
        Lingkaran lingkaran1 = new Lingkaran(154);
        Lingkaran lingkaran2 = new Lingkaran(154, 7);
           
        lingkaran1.printLingkaran();   
        lingkaran2.printLingkaran();
        
    }
}