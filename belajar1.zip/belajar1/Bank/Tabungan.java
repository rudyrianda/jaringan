package Bank;

public class Tabungan {
    private int saldo;
    public Tabungan(int saldoAwal){
        this.saldo = saldoAwal;
    }
    public void simpanUang(int jumlah){
        this.saldo += jumlah;
    }
    public boolean ambilUang(int jumlah){
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah;
            return true;
        } else {
            return false;
        }
    }
    public int getSaldo(){
        return this.saldo;
    }
    public boolean transfer(Tabungan tujuan, int jumlah){
        if (this.ambilUang(jumlah)) {
            tujuan.simpanUang(jumlah);
            return true;
        } else {
            return false;
        }
    }

}
