package Bank;

public class MainT {
    public static void main(String[] args) {
        Tabungan tab1 = new Tabungan(5000);
        Tabungan tab2 = new Tabungan(10000);

        System.out.println("Saldo awal tabungan 1 = " + tab1.getSaldo());
        System.out.println("Simpan uang 2000 ke tabungan 1");
        tab1.simpanUang(2000);
        System.out.println("Saldo tabungan 1 = " + tab1.getSaldo());
        System.out.println("Ambil uang 600 dari tabungan 1");
        tab1.ambilUang(600);
        System.out.println("Saldo tabungan 1 = " + tab1.getSaldo());
        System.out.println("Saldo tabungan 2 = " + tab2.getSaldo());
        tab2.transfer(tab1, 1000);
        System.out.println("Transfer 1000 dari tabungan 2 ke tabungan 1");
        System.out.println("Saldo tabungan 1 = " + tab1.getSaldo());
        System.out.println("Saldo tabungan 2 = " + tab2.getSaldo());



    }
}
