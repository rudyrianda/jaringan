package Mobil.Version2;

public class MainVehicleV2 {
    public static void main(String[] args) {
        Vehicle truck1 = new Vehicle (10000);
        System.out.println("Add load #1 100kg");
        truck1.addBox(100);
        System.out.println("Add load #2 500kg");
        truck1.addBox(500);
        System.out.println("Add load #3 6000kg");
        truck1.addBox(6000);
        System.out.println("Add load #4 3000kg");
        truck1.addBox(3000);
        System.out.println("Add load #5 2000kg");
        truck1.addBox(2000);
        System.out.println("Final load = " + truck1.getLoad() + "kg");
    }
}
