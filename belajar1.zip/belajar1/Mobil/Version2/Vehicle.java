package Mobil.Version2;

public class Vehicle {
    private double load;
    private double maxLoad;

    public Vehicle (double maxLoad) {
        this.maxLoad = maxLoad;
        this.load = 0;
    }
    public boolean addBox(double weight){
        if (this.load + weight <= this.maxLoad) {
            this.load += weight;
            System.out.println("Success add load " + weight + "kg");
            return true;
        } else {
            System.out.println("Failed add load " + weight + "kg");
            return false;
        }
    }
    public double getLoad() {
        return load;
    }
    public double getMaxLoad() {
        return maxLoad;
    }
}
