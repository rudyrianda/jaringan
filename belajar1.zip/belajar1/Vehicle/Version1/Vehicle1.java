package Vehicle.Version1;

public class Vehicle1 {
    public double load;
    public double maxLoad;

    public Vehicle1(double maxLoad) {
        this.maxLoad = maxLoad;
        this.load = 0;
    }
    public double getLoad() {
        return load;
    }
    public double getMaxLoad() {
        return maxLoad;
    }
    
}
