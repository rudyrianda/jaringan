package Vehicle.Version1;

public class MainVehicle {
    public static void main(String[] args) {
        Vehicle1 truck1 = new Vehicle1 (10000);
        System.out.println("Add load #1 100kg");
        truck1.load += 100;
        System.out.println("Add load #2 500kg");
        truck1.load += 500;
        System.out.println("Add load #3 6000kg");
        truck1.load += 6000;
        System.out.println("Add load #4 5000kg");
        truck1.load += 5000;
        System.out.println("Final load = " + truck1.load + "kg");
    }
}
